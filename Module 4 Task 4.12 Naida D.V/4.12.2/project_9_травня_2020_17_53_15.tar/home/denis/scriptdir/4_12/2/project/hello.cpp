#include <iostream>
#include "functions.h"

using namespace std;

void print_hello(){
   cout << "I don't want to set the world on fire!";
}
